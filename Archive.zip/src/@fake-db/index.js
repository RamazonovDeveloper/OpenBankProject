import mock from './mock' 

 import './auth/jwt' 

 mock.onAny().passThrough()