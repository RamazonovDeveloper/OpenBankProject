import React, { useState } from 'react'
import PaymentRepository from 'src/repositories/PaymentRepository'
import AccountRepository from 'src/repositories/AccountRepository'
import { parsePaymentBalance2 } from 'src/utils/sumWithPenny'

export default function usePaymentFilter() {
  const [rowItems, setRowItems] = useState([])
  const [accountItems, setAccountItems] = useState([])
  const [error, setError] = useState(null)

  const [date_from, setDate_from] = useState(null)
  const [date_till, setDate_till] = useState(null)
  const [type, setType] = useState(null)
  const [account_id, setAccount_id] = useState(null)
  const [receiver_inn, setReceiver_inn] = useState(null)
  const [page, setPage] = useState(null)

  return {
    rowItems,
    error,
    accountItems,
    data: {
      date_from,
      date_till,
      type,
      account_id,
      receiver_inn,
      page
    },
    setError: status => {
      setError(status)
    },
    setAccount_id: id => {
      setAccount_id(id)
    },
    setType: type => {
      setType(type)
    },
    setDate_from: from => {
      setDate_from(from)
    },
    setDate_till: till => {
      setDate_till(till)
    },
    setReceiver_inn: inn => {
      setReceiver_inn(inn)
    },
    getPaymentsList: async () => {
      const params = {
        account_id: account_id,
        type: type,
        date_from: date_from,
        date_till: date_till,
        receiver_inn: receiver_inn
      }
      let paymentsList = await PaymentRepository.getPayments(params)
      console.log('paymentsList paymentsList', paymentsList)
      if (paymentsList) {
        let parsedBalancePayments = parsePaymentBalance2(paymentsList.data)
        setRowItems(parsedBalancePayments)
        setError(null)
      } else {
        setError(true)
      }
    },

    confirmPayment: async params => {
      // console.log(params)

      let paymentsList = await PaymentRepository.confirmPayment(params)
      console.log('paymentsList', paymentsList)

      return paymentsList
    },
    getAccountsList: async () => {
      let accountsList = await AccountRepository.getAccounts()

      if (accountsList) {
        setAccountItems(accountsList)
        setError(null)
      } else {
        setError(true)
      }
    }
  }
}
