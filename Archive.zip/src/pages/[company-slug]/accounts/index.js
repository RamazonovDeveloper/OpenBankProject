import { useRouter } from 'next/router'
import { useEffect, useState } from 'react'

// ** MUI Imports
// import TableBasic from 'src/views/table/TableBasic'
import AccountHeader from 'src/views/apps/accounts/AccountHeader'
import Card from '@mui/material/Card'
import Typography from '@mui/material/Typography'
import Grid from '@mui/material/Grid'
import Modal from '@mui/material/Modal'
import Alert from '@mui/material/Alert'
import Box from '@mui/material/Box'
import Button from '@mui/material/Button'
import TableBasic from 'src/views/table/data-grid/TableBasic'
import useAccount from 'src/hooks/useAccount'
import AccountRepository from 'src/repositories/AccountRepository'
import Dialog from '@mui/material/Dialog'
import DialogActions from '@mui/material/DialogActions'
import DialogTitle from '@mui/material/DialogTitle'

import Icon from 'src/@core/components/icon'

import IconButton from '@mui/material/IconButton'

const columns = [
  {
    flex: 0.1,
    field: 'account',
    headerName: 'Счёт',
    align: 'left',
    minWidth: 200
  },
  {
    flex: 0.1,
    field: 'balance',
    headerName: 'Остаток',
    align: 'left',
    minWidth: 120,
    renderCell: params => {
      return (
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <Typography sx={{ mr: 4 }} variant='body2' gutterBottom>
            {params.row.balance}
          </Typography>
          <IconButton color='inherit' sx={{ ml: -2.75 }}>
            <Icon icon='ep:refresh' />
          </IconButton>
        </Box>
      )
    }
  },

  // {
  //   flex: 0.1,
  //   field: 'type',
  //   headerName: 'Тип',
  //   align: 'left',
  //   minWidth: 120
  // },
  {
    flex: 0.1,
    field: 'state',
    headerName: 'Состояние',
    align: 'left',
    minWidth: 170,
    renderCell: params => {
      return (
        <Box>
          {params.row.state === 3 && (
            <Typography variant='body2' gutterBottom>
              ЗАКРЫТО
            </Typography>
          )}
          {params.row.state === 2 && (
            <Typography variant='body2' gutterBottom>
              ОТКРЫТО
            </Typography>
          )}
        </Box>
      )
    }
  },
  {
    flex: 0.1,
    field: 'bank_name',
    headerName: 'Банк',
    align: 'left',
    minWidth: 170
  },
  {
    flex: 0.1,
    field: 'last_balance_synced_time',
    headerName: 'Время последней с. б.',
    align: 'left',
    minWidth: 170
  }
]

const rows = [
  {
    id: '1',
    account_number: 23120000002560000257,
    sum_residue: '4 200 422,00 UZS',
    status: 'Открыт',
    type: 'Расчётный',
    bank: 'Agrobank'
  },
  {
    id: 2,
    account_number: 23120000004190000143,
    sum_residue: '2 500 000,00 UZS',
    status: 'Открыт',
    type: 'Расчётный',
    bank: 'AsakaBank'
  },
  {
    id: 3,
    account_number: 23120000009630000631,
    sum_residue: '45 678,00 USD',
    status: 'Открыт',
    type: 'Расчётный',
    bank: 'KapitalBank'
  },
  {
    id: 4,
    account_number: 23120000002560000257,
    sum_residue: '2 885 036,00 UZS',
    status: 'Открыт',
    type: 'Расчётный',
    bank: 'Agrobank'
  }
]

const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4
}

const Payments = () => {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [loading, setLoading] = useState(false)

  const { getAccountsList, loadingSingleAsync, accountSync, accountItems, sum, accountsSync, loadingAsync } =
    useAccount()

  useEffect(() => {
    getAccountsList()
  }, [])

  const handleClick = e => {
    // router.push(`/accounts/preview/${1}`)
  }

  const addNewItem = async e => {
    setLoading(true)

    const ress = await AccountRepository.accountsFromBanks()
    getAccountsList()
    console.log('bank accounts ', ress)
    setOpen(!open)
    setLoading(false)

    // router.push(`/accounts/add`)
  }

  const reloadAccount = e => {
    console.log('e', e)
    accountSync(e.id)
    setTimeout(() => {
      getAccountsList()
    }, 2000)
  }

  return (
    <Grid container spacing={4}>
      <Grid item xs={12}>
        <AccountHeader
          accountsSync={accountsSync}
          loading={loading}
          sum={sum}
          addNewItem={() => setOpen(true)}
          loadingAsync={loadingAsync}
        />
      </Grid>

      <Grid item xs={12}>
        <Card>
          <TableBasic reloadAccount={reloadAccount} rows={accountItems} columns={columns} handleClick={handleClick} />
        </Card>
      </Grid>

      <Dialog open={open} onClose={() => setOpen(false)}>
        <DialogTitle>Вы уверены, что создаете новый аккаунт?</DialogTitle>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>Отмена</Button>
          <Button onClick={addNewItem}>Создать</Button>
        </DialogActions>
      </Dialog>
    </Grid>
  )
}

export default Payments
