import React from 'react'

function index() {
  return (
    <div>
      This is a Pick up a loan page
      There you can see some  items
    </div>
  )
}

export default index
