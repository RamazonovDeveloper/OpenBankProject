import React from 'react'

import CreditPreviewComponent from 'src/views/apps/credits/preview/Preview'

function CreditPreview() {
  return <CreditPreviewComponent id={id='4987'}/>
}

export default CreditPreview
