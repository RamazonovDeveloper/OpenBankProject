import Link from 'next/link'
import { useRouter } from 'next/router'
import { useEffect } from 'react'

// ** MUI Imports
import Card from '@mui/material/Card'
import Grid from '@mui/material/Grid'
import Typography from '@mui/material/Typography'
import CardHeader from '@mui/material/CardHeader'
import CardContent from '@mui/material/CardContent'
import { DataGrid } from '@mui/x-data-grid'
import IconButton from '@mui/material/IconButton'
import Icon from 'src/@core/components/icon'
import Box from '@mui/material/Box'
import Accounts from 'src/views/dashboards/accounts/Accounts'
import Tooltip from '@mui/material/Tooltip'

import TableHeader from 'src/views/apps/invoice/list/TableHeader'
import CardItems from 'src/views/dashboards/card/CardItems'
import TableFilter from 'src/views/table/data-grid/TableFilter'
import usePayment from 'src/hooks/usePayment'
import Dialog from '@mui/material/Dialog'
import DialogActions from '@mui/material/DialogActions'
import DialogContent from '@mui/material/DialogContent'
import DialogContentText from '@mui/material/DialogContentText'
import DialogTitle from '@mui/material/DialogTitle'
import Button from '@mui/material/Button'
import Chip from '@mui/material/Chip'
import Stack from '@mui/material/Stack'

const columns = [
  // { field: 'id', headerName: 'ID', minWidth: 20 },
  {
    field: 'sent_date',
    headerName: 'Дата',
    minWidth: 120,
    renderCell: params => {
      return (
        <Box>
          <Typography variant='body2' gutterBottom>
            {params.row.sent_date.slice(0, 10)}
          </Typography>
        </Box>
      )
    }
  },
  {
    field: 'contragent',
    headerName: 'Контрагент',
    minWidth: 240,
    renderCell: params => {
      return (
        <Box>
          <Typography variant='body1' gutterBottom>
            {params.row.doc_account}
          </Typography>
          <Typography variant='body2' gutterBottom>
            {params.row.doc_inn}
          </Typography>
          {params.row.doc_type === 1 && (
            <Typography variant='caption' display='block' gutterBottom>
              Платёж контрагенту
            </Typography>
          )}
          {params.row.doc_type === 2 && (
            <Typography variant='caption' display='block' gutterBottom>
              Платеж казначейству
            </Typography>
          )}
          {params.row.doc_type === 3 && (
            <Typography variant='caption' display='block' gutterBottom>
              Выплата по зарплатному проекту
            </Typography>
          )}
          {params.row.doc_type === 4 && (
            <Typography variant='caption' display='block' gutterBottom>
              Платеж в бюджет
            </Typography>
          )}
        </Box>
      )
    }
  },
  {
    field: 'amount',
    headerName: 'Сумма',
    minWidth: 190,
    renderCell: params => {
      return (
        <Box>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <Typography sx={{ mr: 4 }} variant='body2' gutterBottom>
              {params.row.amount}
            </Typography>
            <IconButton color='inherit' sx={{ ml: -2.75 }}>
              <Icon icon='ep:refresh' />
            </IconButton>
          </Box>
        </Box>
      )
    }
  },
  {
    field: 'status',
    headerName: 'СТАТУС',
    minWidth: 170,
    renderCell: params => {
      return (
        <Box>
          <Stack direction='row' spacing={1}>
            {(params.row.status === 1 || params.row.status === 2) && (
              <Chip label='Создан' color='warning' variant='outlined' />
            )}
          </Stack>

          {params.row.status === 3 && <Chip label='Отправлен в банк' color='success' variant='outlined' />}
        </Box>
      )
    }
  },

  // {
  //   field: 'payments',
  //   headerName: 'Счёт',
  //   minWidth: 210,
  //   renderCell: params => {
  //     return (
  //       <Box>
  //         <Typography variant='body2' gutterBottom>
  //           {params.row.doc_inn}
  //         </Typography>
  //       </Box>
  //     )
  //   }
  // },
  {
    field: 'bank',
    headerName: 'Банк',
    minWidth: 130,
    renderCell: params => {
      return <Box>agrobank</Box>
    }
  }

  // {
  //   field: '',
  //   headerName: 'СТАТУС',
  //   minWidth: 210,
  //   renderCell: params => {
  //     return (
  //       <Box>
  //         <Button variant='outlined'>
  //           <Icon icon='ep:check' /> Подтвердить
  //         </Button>
  //       </Box>
  //     )
  //   }
  // }
]

const rows = [
  {
    id: 1,
    date: '13.12.2022',
    contragent: ['Платёжное поручение №3091', 'Контрагент 2', 'В том числе НДС 15% - 1 500 сум.'],
    sum: '-10 000,00 UZS',
    status: 'Подтверждён'
  },
  {
    id: 2,
    date: '13.12.2022',
    contragent: ['Платёжное поручение №0481', 'Контрагент 1', 'В том числе НДС 15% - 1 500 сум.'],
    sum: '-10 000,00 UZS',
    status: 'Подтверждён'
  },
  {
    id: 3,
    date: '13.12.2022',
    contragent: ['Платёжное поручение №62838', 'Контрагент 9', 'Оплата услуг'],
    sum: '-1 700,00 UZS',
    status: 'Подтверждён'
  },
  {
    id: 4,
    date: '13.12.2022',
    contragent: ['Платёжное поручение №66189', 'Контрагент 8', 'Оплата услуг'],
    sum: '-2 500,00 UZS',
    status: 'Подтверждён'
  },
  {
    id: 5,
    date: '13.12.2022',
    contragent: ['Платёжное поручение №46733', 'Контрагент 7', 'Оплата услуг'],
    sum: '-1 300,00 UZS',
    status: 'Подтверждён'
  },
  {
    id: 6,
    date: '13.12.2022',
    contragent: ['Платёжное поручение №3091', 'Контрагент 6', 'Оплата услуг'],
    sum: '-7 424,00 UZS',
    status: 'Подтверждён'
  },
  {
    id: 7,
    date: '13.12.2022',
    contragent: ['Платёжное поручение №3091', 'Контрагент 3', 'Оплата услуг'],
    sum: '-4 123,00 UZS',
    status: 'Подтверждён'
  },
  {
    id: 8,
    date: '13.12.2022',
    contragent: ['Платёжное поручение №3091', 'Контрагент 5', 'Оплата услуг'],
    sum: '-3 248,00 UZS',
    status: 'Подтверждён'
  },
  {
    id: 9,
    date: '13.12.2022',
    contragent: ['Платёжное поручение №3091', 'Контрагент 10', 'Оплата услуг'],
    sum: '-2 804,00 UZS',
    status: 'Подтверждён'
  }
]

const Home = () => {
  const router = useRouter()

  const {
    data,
    error,
    setError,
    getPaymentsList,
    getAccountsList,
    rowItems,
    accountItems,
    setAccount_id,
    setType,
    setDate_from,
    setDate_till,
    setReceiver_inn
  } = usePayment()

  const companyInfo = JSON.parse(localStorage.getItem('companyInfo'))

  useEffect(() => {
    getPaymentsList()
    getAccountsList()
  }, [data.account_id, data.type, data.date_from, data.date_till, data.receiver_inn])

  const handleClick = e => {
    router.push(`/payments/preview/${1}`)
  }

  return (
    <Grid container spacing={4}>
      <CardItems />
      <Grid item xs={12} sm={6} md={9}>
        <Card>
          {/* <TableHeader /> */}
          <TableFilter
            accountItems={accountItems}
            setAccount_id={setAccount_id}
            setType={setType}
            setDate_from={setDate_from}
            setDate_till={setDate_till}
            setReceiver_inn={setReceiver_inn}
            data={data}
            rows={rowItems}
            columns={columns}
            handleClick={handleClick}
          />
        </Card>
      </Grid>
      <Grid item xs={12} sm={6} md={3}>
        <Accounts accountItems={accountItems} />
      </Grid>
      <Dialog
        open={error}
        keepMounted
        onClose={() => setError(false)}
        aria-describedby='alert-dialog-slide-description'
      >
        <DialogTitle>{'Oh no! Something went wrong'}</DialogTitle>
        <DialogActions>
          <Button onClick={() => router.push(`/login`)}>Попробуйте еще раз</Button>
        </DialogActions>
      </Dialog>
    </Grid>
  )
}

export default Home
