// ** MUI Imports
import Grid from '@mui/material/Grid'

import PaymentCards from 'src/views/apps/autopayments/PaymentCards'
import PaymentsHeader from 'src/views/apps/payments/PaymentsHeader'

const Payments = () => {
  return (
    <Grid container spacing={4}>
      <Grid item xs={12}>
        <PaymentsHeader />
      </Grid>

      <Grid item xs={12}>
        <PaymentCards />
      </Grid>
    </Grid>
  )
}

export default Payments
