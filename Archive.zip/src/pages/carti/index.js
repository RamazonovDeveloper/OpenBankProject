import React from 'react'

import Stack from '@mui/material/Stack'
import Button from '@mui/material/Button'
import Icon from 'src/@core/components/icon'

//select
import InputLabel from '@mui/material/InputLabel'
import MenuItem from '@mui/material/MenuItem'
import FormControl from '@mui/material/FormControl'
import Select from '@mui/material/Select'

// tabs
import PropTypes from 'prop-types'
import Tabs from '@mui/material/Tabs'
import Tab from '@mui/material/Tab'
import Typography from '@mui/material/Typography'
import Box from '@mui/material/Box'

// table
import Table from '@mui/material/Table'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TableHead from '@mui/material/TableHead'
import TableRow from '@mui/material/TableRow'
import Paper from '@mui/material/Paper'

//modal
import Modal from '@mui/material/Modal'

const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 900,
  height: 600,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 5,
  borderRadius: '20px'
}

function TabPanel(props) {
  const { children, value, index, ...other } = props

  return (
    <div
      role='tabpanel'
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  )
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired
}

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`
  }
}

const ModalButtons = [
  {
    type: false,
    name: 'Последние 10 операций'
  },
  {
    type: false,
    name: 'Льготный период'
  },
  {
    type: false,
    name: 'Обслуживание и услуги'
  },
  {
    type: false,
    name: 'Привилегии'
  }
]

const rowMass = [
  {
    id: 1,
    dealNomer: '142104',
    date: '13.12.2022',
    inn: 23120000002560000257,
    contragent: ["ООО 'Future Open Technolofy'", 'В том числе НДС 20% 2000 sum.'],
    typeSum: 'В том числе НДС 20% 2000 sum ',
    sum: '4 200 422,00 UZS',
    depositSum: '1 200 500 sum',
    sana: 'Yanvar 2022',
    status: 'Расчётный',
    statusPay: false,
    level: 'Открыт',
    bank: 'Xalq bank',
    rontragent: 0,
    img_src:
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQR2p2bSW8eA9sKl6Zg6yKgTCNoPUSCBIz3IWstJLXk7r1VdXD1OukZmoERizJ9XvJl5tA&usqp=CAU',
    bankNum: '9860*******3202',
    cardDate: '10/2022'
  },
  {
    id: 2,
    dealNomer: '142104',
    date: '13.12.2022',
    inn: 23120000002560000257,
    contragent: ["ООО 'Future Open Technolofy'", 'В том числе НДС 20% 2000 sum.'],
    typeSum: 'В том числе НДС 20% 2000 sum ',
    sum: '4 200 422,00 UZS',
    depositSum: '1 200 500 sum',
    sana: 'Yanvar 2022',
    status: 'Расчётный',
    statusPay: false,
    level: 'Открыт',
    bank: 'Agro Bank',
    rontragent: 0,
    img_src:
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRLTBJuabwFMveoks4ffDvmsTPJLBpv0qvGnF_Atl2wDOE-bM2jlg8uFgj1VJ2HXTnyXC0&usqp=CAU',
    bankNum: '8600*******1202',
    cardDate: '03/2024'
  },
  {
    id: 3,
    dealNomer: '142104',
    date: '13.12.2022',
    inn: 23120000002560000257,
    contragent: ["ООО 'Future Open Technolofy'", 'В том числе НДС 20% 2000 sum.'],
    typeSum: 'В том числе НДС 20% 2000 sum ',
    sum: '4 200 422,00 UZS',
    depositSum: '1 200 500 sum',
    sana: 'Yanvar 2022',
    status: 'Расчётный',
    statusPay: false,
    level: 'Открыт',
    bank: 'Xalq bank',
    rontragent: 0,
    img_src:
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTyPBQ9yiIuflPDVLfjx7QkpXsRRXlkP4BxT8Taam7glpLq9EQUFefHPnSLoCiIH-GZkGw&usqp=CAU',
    bankNum: '9860*******8802',
    cardDate: '07/2023'
  }
]

export default function Carti() {
  const [age, setAge] = React.useState('')

  const handleChange2 = event => {
    setAge(event.target.value)
  }

  //tabs
  const [value, setValue] = React.useState(0)

  const handleChange = (event, newValue) => {
    setValue(newValue)
  }

  // tables
  function createData(name, calories, fat, carbs, protein) {
    return { name, calories, fat, carbs, protein }
  }

  const rows = [
    createData('Frozen yoghurt', 159, 6.0, 24, 4.0),
    createData('Ice cream sandwich', 237, 9.0, 37, 4.3),
    createData('Eclair', 262, 16.0, 24, 6.0),
    createData('Cupcake', 305, 3.7, 67, 4.3),
    createData('Gingerbread', 356, 16.0, 49, 3.9)
  ]

  //modal
  const [open, setOpen] = React.useState(false)
  const [boshMas, setBoshMas] = React.useState([])

  // const handleOpen = () =>
  // const handleClose = () => ;
  function handleClose() {
    setBoshMas([])
    setOpen(false)
  }

  function handleOpen(item) {
    boshMas.push(item)
    setOpen(true)
    console.log(boshMas, 'men new resultaman')
  }

  //   const [boshMas, setBoshMas] = React.useState([]);

  //  function handleClose() {
  //   setOpen(false);
  //   setBoshMas([])
  //  }
  //  function handleOpen(item) {
  //   boshMas.push(item)
  //   setOpen(true)
  //  }

  return (
    <div>
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          background: ''
        }}
      >
        <h2>Бизнес-карты</h2>
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '20px'
          }}
        >
          <p>Счёт</p>
          <FormControl sx={{ width: '300px', m: 1, minWidth: 120 }} size='small'>
            <InputLabel id='demo-select-small'>Выберите счёт</InputLabel>
            <Select
              labelId='demo-select-small'
              id='demo-select-small'
              value={age}
              label='Выберите счёт'
              onChange={handleChange2}
            >
              <MenuItem value=''>
                <em>None</em>
              </MenuItem>
              <MenuItem value={10}>ООО "ТЕСТ"40702.810.9.0894331808475 130</MenuItem>
              <MenuItem value={20}>ООО "ТЕСТ"40702.810.9.0894331808475 130</MenuItem>
              <MenuItem value={30}>ООО "ТЕСТ"40702.810.7.230936511359 456 328</MenuItem>
            </Select>
          </FormControl>
          <Button variant='outlined'>Экспорт списка</Button>
          <Button variant='contained'>Новая карта</Button>
        </div>
      </div>
      <div>
        <Box sx={{ width: '100%' }}>
          <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
            <Tabs value={value} onChange={handleChange} aria-label='basic tabs example'>
              <Tab label='Карты' {...a11yProps(0)} />
              <Tab label='Держатели карт' {...a11yProps(1)} />
              <Tab label='Заявления' {...a11yProps(2)} />
              <Tab label='Отчёты' {...a11yProps(3)} />
            </Tabs>
          </Box>
          <TabPanel value={value} index={0}>
            <div style={{ marginTop: '20px' }}>
              <div
                style={{
                  display: 'flex',
                  gap: '200px',
                  alignItems: 'center'
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    gap: '30px',
                    alignItems: 'center'
                  }}
                >
                  <p>Держатель</p>
                  <input
                    style={{
                      width: '300px',
                      height: '40px',
                      background: 'none',
                      borderRadius: '8px',
                      border: '1px solid #c9c9c9',
                      outlineColor: 'blue',
                      paddingLeft: '20px',
                      fontSize: '17px',
                      color: '#ababab'
                    }}
                    type='input'
                    placeholder='Ввудите данные держателя'
                  />
                </div>
                <div
                  style={{
                    display: 'flex',
                    gap: '30px'
                  }}
                >
                  <p>Тип карты</p>
                  <FormControl sx={{ width: '300px', m: 1, minWidth: 120 }} size='small'>
                    <InputLabel id='demo-select-small'>Тип карты</InputLabel>
                    <Select
                      labelId='demo-select-small'
                      id='demo-select-small'
                      value={age}
                      label='Выберите счёт'
                      onChange={handleChange2}
                    >
                      <MenuItem value=''>
                        <em>None</em>
                      </MenuItem>
                      <MenuItem value={10}>ООО "ТЕСТ"40702.810.9.0894331808475 130</MenuItem>
                      <MenuItem value={20}>ООО "ТЕСТ"40702.810.9.0894331808475 130</MenuItem>
                      <MenuItem value={30}>ООО "ТЕСТ"40702.810.7.230936511359 456 328</MenuItem>
                    </Select>
                  </FormControl>
                </div>
              </div>
              <div style={{ marginTop: '30px' }}>
                <TableContainer component={Paper}>
                  <Table sx={{ minWidth: 650 }} aria-label='simple table'>
                    <TableHead>
                      <TableRow>
                        <TableCell>No</TableCell>
                        <TableCell>Тип карты</TableCell>
                        <TableCell>Держатель</TableCell>
                        <TableCell>Номер карты</TableCell>
                        <TableCell>Срок действия</TableCell>
                        <TableCell>Баланс</TableCell>
                        <TableCell>Статус</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {rowMass.map((item, index) => (
                        <TableRow className='modalStyle' onClick={() => handleOpen(item)} key={index}>
                          <TableCell> {item.id}</TableCell>
                          <TableCell>
                            <img width={'100px'} src={item.img_src} alt='' />
                          </TableCell>
                          <TableCell> {item.bank}</TableCell>
                          <TableCell> {item.bankNum}</TableCell>
                          <TableCell> {item.cardDate}</TableCell>
                          <TableCell> {item.depositSum}</TableCell>
                          <TableCell>
                            {' '}
                            <p
                              style={{
                                width: '100px',
                                height: '30px',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '5px'
                              }}
                            >
                              <Icon style={{ color: '#0b7943' }} icon='material-symbols:check-circle-rounded' />
                              {item.status}
                            </p>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                    <div>
                      <Modal
                        open={open}
                        onClose={handleClose}
                        aria-labelledby='modal-modal-title'
                        aria-describedby='modal-modal-description'
                      >
                        <Box sx={style}>
                          {boshMas.length > 0 ? (
                            boshMas.map((item, index) => {
                              return (
                                <div key={index}>
                                  <h2 style={{ textAlign: 'center' }}>Кредитная бизнес-карта Visa</h2>
                                  <div
                                    style={{
                                      display: 'flex',
                                      alignItems: 'center',
                                      justifyContent: 'space-between'
                                    }}
                                  >
                                    <img src={item.img_src} alt='' />
                                    <ul>
                                      <li style={{ marginTop: '20px' }}>Держатель</li>
                                      <li style={{ marginTop: '20px' }}>Карта действует до</li>
                                      <li style={{ marginTop: '20px' }}>Баланс</li>
                                    </ul>
                                    <ul>
                                      <li style={{ marginTop: '20px' }}>{item.contragent}</li>
                                      <li style={{ marginTop: '20px' }}>{item.date}</li>
                                      <li
                                        style={{ marginTop: '20px', fontSize: '20px', fontWeight: 700, color: '#000' }}
                                      >
                                        {item.depositSum}
                                      </li>
                                    </ul>
                                  </div>
                                  <div style={{ display: 'flex', gap: '100px' }}>
                                    <p>Задолженность:◼ 0,00 </p>
                                    <p>Обязательный платёж:◼ 0,00</p>
                                  </div>
                                  <div>
                                    <div className='' style={{ display: 'flex', gap: '10px' }}>
                                      {ModalButtons.length > 0 &&
                                        ModalButtons.map((item, index) => {
                                          return (
                                            <div key={index}>
                                              <button className={item.type === true ? `madalButton1` : `madalButton2`}>
                                                {item.name}
                                              </button>
                                            </div>
                                          )
                                        })}
                                    </div>
                                  </div>
                                </div>
                              )
                            })
                          ) : (
                            <h2>Loading......</h2>
                          )}
                        </Box>
                      </Modal>
                    </div>
                  </Table>
                </TableContainer>
              </div>
            </div>
          </TabPanel>
          <TabPanel value={value} index={1}>
            Нет данных
          </TabPanel>
          <TabPanel value={value} index={2}>
            Нет данных
          </TabPanel>
          <TabPanel value={value} index={2}>
            Нет данных
          </TabPanel>
        </Box>
      </div>
    </div>
  )
}
