import * as React from 'react'
import Grid from '@mui/material/Grid'
import Card from '@mui/material/Card'
import DepositTabLists from 'src/views/apps/depozit/DepositTabLists'
import DepositHeader from 'src/views/apps/depozit/DepositHeader'

//step
const Depozit = () => {
  return (
    <Grid container spacing={4}>
      <Grid item xs={12}>
        <DepositHeader />
      </Grid>
      <Card item xs={12}>
        <DepositTabLists />
      </Card>
    </Grid>
  )
}

export default Depozit
