import Link from 'next/link'
import { useRouter } from 'next/router'

// ** MUI Imports
import Card from '@mui/material/Card'
import Grid from '@mui/material/Grid'
import Typography from '@mui/material/Typography'
import CardHeader from '@mui/material/CardHeader'
import CardContent from '@mui/material/CardContent'
import { DataGrid } from '@mui/x-data-grid'
import Tooltip from '@mui/material/Tooltip'
import IconButton from '@mui/material/IconButton'
import Button from '@mui/material/Button'
import Box from '@mui/material/Box'

import OptionsMenu from 'src/@core/components/option-menu'
import Icon from 'src/@core/components/icon'

import Accounts from 'src/views/dashboards/accounts/Accounts'

import DocumentHeader from 'src/views/apps/document/DocumentHeader'
import TableHeader from 'src/views/apps/document/TableHeader'
import TableBasic from 'src/views/table/data-grid/TableBasic'

const columns = [
  { field: 'number', headerName: '№', minWidth: 60 },
  { field: 'date', headerName: 'Дата', minWidth: 120 },
  {
    field: 'sum',
    headerName: 'Сумма',
    minWidth: 150
  },
  {
    field: 'status',
    headerName: 'Статус',
    minWidth: 110
  },
  {
    field: 'payments',
    headerName: 'Счёт',
    minWidth: 210,
    renderCell: params => {
      return (
        <Box>
          <Typography variant='body2' gutterBottom>
            {params.row.payments[0]}
          </Typography>
        </Box>
      )
    }
  },
  {
    field: 'bank',
    headerName: 'Банк',
    minWidth: 130
  },
  {
    flex: 0.1,
    minWidth: 130,
    sortable: false,
    field: 'actions',
    headerName: 'ДЕЙСТВИЯ',
    renderCell: ({ row }) => (
      <Box sx={{ display: 'flex', alignItems: 'center' }}>
        <Tooltip title='Удалить платеж'>
          <IconButton size='small' sx={{ mr: 0.5 }}>
            <Icon icon='mdi:delete-outline' />
          </IconButton>
        </Tooltip>
        <Tooltip title='Посмотреть'>
          <IconButton size='small' component={Link} sx={{ mr: 0.5 }} href={`/payments/preview/${1}`}>
            <Icon icon='mdi:eye-outline' />
          </IconButton>
        </Tooltip>
        <OptionsMenu
          iconProps={{ fontSize: 20 }}
          iconButtonProps={{ size: 'small' }}
          menuProps={{ sx: { '& .MuiMenuItem-root svg': { mr: 2 } } }}
          options={[
            {
              text: 'Скачать',
              icon: <Icon icon='mdi:download' fontSize={20} />
            },
            {
              text: 'Редактировать',

              // href: `/apps/invoice/edit/${row.id}`,
              icon: <Icon icon='mdi:pencil-outline' fontSize={20} />
            },
            {
              text: 'Дублировать',
              icon: <Icon icon='mdi:content-copy' fontSize={20} />
            }
          ]}
        />
      </Box>
    )
  }
]

const rows = [
  {
    number: 9119,
    id: 1,
    date: '13.12.2022',
    contragent: ['Платёжное поручение №3091', 'Контрагент 2', 'В том числе НДС 15% - 1 500 сум.'],
    sum: '-10 000,00 UZS',
    status: 'Подписан',
    payments: ['23120000002560000257', "ООО 'Future Open Technolofy'", 'В том числе НДС 20% 2000 рублей.'],
    bank: 'Agrobank'
  },
  {
    number: 8143,
    id: 2,
    date: '13.12.2022',
    contragent: ['Платёжное поручение №0481', 'Контрагент 1', 'В том числе НДС 15% - 1 500 сум.'],
    sum: '-10 000,00 UZS',
    status: 'Исполнен',
    payments: ['23120000004190000143', "ООО 'Future Open Technolofy'", 'В том числе НДС 20% 2000 рублей.'],
    bank: 'Asakabank'
  },
  {
    number: 7653,
    id: 3,
    date: '13.12.2022',
    contragent: ['Платёжное поручение №62838', 'Контрагент 9', 'Оплата услуг'],
    sum: '-1 200, 00 USD',
    status: 'Исполнен',
    payments: ['23120000009630000631', "ООО 'Future Open Technolofy'", 'В том числе НДС 20% 2000 рублей.'],
    bank: 'KapitalBank'
  },
  {
    number: 3452,
    id: 4,
    date: '13.12.2022',
    contragent: ['Платёжное поручение №66189', 'Контрагент 8', 'Оплата услуг'],
    sum: '-2 500,00 UZS',
    status: 'Исполнен',
    payments: ['23120000002560000257', "ООО 'Future Open Technolofy'", 'В том числе НДС 20% 2000 рублей.'],
    bank: 'Agrobank'
  },
  {
    number: 2346,
    id: 5,
    date: '13.12.2022',
    contragent: ['Платёжное поручение №46733', 'Контрагент 7', 'Оплата услуг'],
    sum: '-1 300,00 UZS',
    status: 'Исполнен',
    payments: ['23120000002560000257', "ООО 'Future Open Technolofy'", 'В том числе НДС 20% 2000 рублей.'],
    bank: 'Agrobank'
  },
  {
    number: 4567,
    id: 6,
    date: '13.12.2022',
    contragent: ['Платёжное поручение №3091', 'Контрагент 6', 'Оплата услуг'],
    sum: '-7 424,00 UZS',
    status: 'Исполнен',
    payments: ['23120000002560000257', "ООО 'Future Open Technolofy'", 'В том числе НДС 20% 2000 рублей.'],
    bank: 'Agrobank'
  },
  {
    number: 8765,
    id: 7,
    date: '13.12.2022',
    contragent: ['Платёжное поручение №3091', 'Контрагент 3', 'Оплата услуг'],
    sum: '-4 123,00 UZS',
    status: 'Исполнен',
    payments: ['23120000002560000257', "ООО 'Future Open Technolofy'", 'В том числе НДС 20% 2000 рублей.'],
    bank: 'Agrobank'
  },
  {
    number: 3456,
    id: 8,
    date: '13.12.2022',
    contragent: ['Платёжное поручение №3091', 'Контрагент 5', 'Оплата услуг'],
    sum: '-3 248,00 UZS',
    status: 'Исполнен',
    payments: ['23120000002560000257', "ООО 'Future Open Technolofy'", 'В том числе НДС 20% 2000 рублей.'],
    bank: 'Agrobank'
  },
  {
    number: 6542,
    id: 9,
    date: '13.12.2022',
    contragent: ['Платёжное поручение №3091', 'Контрагент 10', 'Оплата услуг'],
    sum: '-2 804,00 UZS',
    status: 'Исполнен',
    payments: ['23120000002560000257', "ООО 'Future Open Technolofy'", 'В том числе НДС 20% 2000 рублей.'],
    bank: 'Agrobank'
  }
]

const Document = () => {
  const router = useRouter()

  const handleClick = e => {
    router.push(`/payments/preview/${1}`)
  }

  const addItem = e => {
    router.push(`/payments/add`)
  }

  return (
    <Grid container spacing={4}>
      <Grid item xs={12}>
        <DocumentHeader addItem={addItem} />
      </Grid>

      <Grid item xs={12}>
        <Card>
          {/* <TableHeader /> */}
          <TableBasic rows={rows} columns={columns} handleClick={handleClick} />
        </Card>
      </Grid>
    </Grid>
  )
}

export default Document
