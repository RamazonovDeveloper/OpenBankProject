import React, { useState } from 'react'
import { useRouter } from 'next/router'
import Icon from 'src/@core/components/icon'
import Button from '@mui/material/Button'
import LogoIcon from 'public/images/favicon.png'
import Image from 'next/image'
import TableCollapsible from 'src/views/table/mui/TableCollapsible'

//pages
import ReportPage from './itemTabs/reportPage'

// tabs
import PropTypes from 'prop-types'
import Tabs from '@mui/material/Tabs'
import Tab from '@mui/material/Tab'
import Typography from '@mui/material/Typography'
import Box from '@mui/material/Box'

import InputLabel from '@mui/material/InputLabel'
import MenuItem from '@mui/material/MenuItem'
import FormControl from '@mui/material/FormControl'
import Select from '@mui/material/Select'

// according
import Accordion from '@mui/material/Accordion'
import AccordionDetails from '@mui/material/AccordionDetails'
import AccordionSummary from '@mui/material/AccordionSummary'

// Speed Dial
import SpeedDial from '@mui/material/SpeedDial'
import SpeedDialIcon from '@mui/material/SpeedDialIcon'
import SpeedDialAction from '@mui/material/SpeedDialAction'

//check select
import Checkbox from '@mui/material/Checkbox'
import TextField from '@mui/material/TextField'
import Autocomplete from '@mui/material/Autocomplete'

// import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';
// import CheckBoxIcon from '@mui/icons-material/CheckBox';
import AddNewItemModal from 'src/views/apps/ekvayring/addNewItemModal'

const icon = <Icon fontSize='25px' icon='material-symbols:check-box-outline' />
const checkedIcon = <Icon fontSize='25px' icon='material-symbols:check-box' />

//modal

const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 1000,
  bgcolor: 'background.paper',
  borderRadius: 1,
  boxShadow: 24,
  p: 4
}

const rows = [
  {
    id: 1,
    dealNomer: '142104',
    date: '13.12.2022',
    inn: 23120000002560000257,
    contragent: ["ООО 'Future Open Technolofy'", 'В том числе НДС 20% 2000 sum.'],
    typeSum: 'В том числе НДС 20% 2000 sum ',
    sum: '4 200 422,00 UZS',
    depositSum: '1 200 500 sum',
    sana: 'Yanvar 2022',
    status: 'Расчётный',
    statusPay: false,
    level: 'Открыт',
    bank: 'Xalq bank',
    rontragent: 0
  },
  {
    id: 2,
    dealNomer: '842104',
    date: '13.12.2022',
    inn: 83120000002560000257,
    contragent: ["ООО 'Future IT  Technolofy'", 'В том числе НДС 90% 2000 sum.'],
    typeSum: 'В том числе НДС 20% 2000 sum ',
    sum: '8 200 422,00 UZS',
    depositSum: '2 100 500 sum',
    sana: 'Fevral 2022',
    status: 'Расчётный',
    statusPay: true,
    level: 'Открыт',
    bank: 'Davr Bank',
    rontragent: 2
  },

  {
    id: 3,
    dealNomer: '242104',
    date: '13.12.2022',
    inn: 23120000004190000143,
    contragent: ["ООО 'Future Open Technolofy'", 'В том числе НДС 20%  2000 рублей.'],
    typeSum: 'В том числе НДС 40% 2000 sum',
    sum: '2 500 000,00 UZS',
    depositSum: '2 200 500 sum',
    sana: 'Yanvar 2022',
    status: 'Расчётный',
    statusPay: true,
    level: 'Открыт',
    bank: 'AsakaBank',
    rontragent: 3
  },

  {
    id: 4,
    dealNomer: '342104',
    date: '13.12.2022',
    inn: 23120000004190000143,
    contragent: ["ООО 'Future Open Technolofy'", 'Оплата услуг'],
    typeSum: 'В том числе НДС 10% 3000 sum',
    sum: '3 145 678,00 USD',
    sana: 'Yanvar 2022',
    depositSum: '3 500 sum',
    status: 'Расчётный',
    statusPay: false,
    level: 'Открыт',
    bank: 'KapitalBank',
    rontragent: 4
  },

  {
    id: 5,
    dealNomer: '542104',
    date: '13.12.2022',
    inn: 23120000002560000257,
    contragent: ["ООО 'Future Open Technolofy'", 'Оплата услуг'],
    typeSum: 'В том числе НДС 25% 2500 sum',
    sum: '2 885 036,00 UZS',
    sana: 'Yanvar 2022',
    depositSum: '1 200 500 sum',
    status: 'Расчётный',
    statusPay: true,
    level: 'Открыт',
    dealNomer: '642104',
    bank: 'Agrobank',
    rontragent: 5
  }
]

function TabPanel(props) {
  const { children, value, index, ...other } = props

  return (
    <div
      role='tabpanel'
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  )
}

export default function Ekvayring() {
  const router = useRouter()

  // tabs
  const [value, setValue] = useState(0)

  const handleChange2 = (event, newValue) => {
    setValue(newValue)
  }

  const addNewItem = e => {
    router.push(`/ekvayring/add`)
  }

  return (
    <div>
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}
      >
        <h2>Эквайринг</h2>
        <Button onClick={addNewItem} variant='contained' sx={{ mr: 4 }}>
          Добавить
        </Button>
      </div>
      <Box sx={{ width: '100%' }}>
        <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
          <Tabs value={value} onChange={handleChange2} aria-label='basic tabs example'>
            <Tab label='Точки' />
            <Tab label='Заявления' />
            <Tab label='Отчёты' />
            <Tab label='История оплат по QR' />
          </Tabs>
        </Box>
        <TabPanel value={value} index={0}>
          <TableCollapsible rows={rows} />
        </TabPanel>
        <TabPanel value={value} index={1}>
          Нет данных
        </TabPanel>
        <TabPanel value={value} index={2}>
          <ReportPage />
        </TabPanel>
        <TabPanel value={value} index={3}>
          Нет данных
        </TabPanel>
      </Box>
    </div>
  )
}
