import React from 'react'

//table
import Table from '@mui/material/Table'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TableHead from '@mui/material/TableHead'
import TableRow from '@mui/material/TableRow'
import Paper from '@mui/material/Paper'

function createData(name, calories, fat, carbs, protein) {
  return { name, calories, fat, carbs, protein }
}

const rows = [
  {
    id: 1,
    dealNomer: '142104',
    date: '13.12.2022',
    inn: 23120000002560000257,
    contragent: ["ООО 'Future Open Technolofy'", 'В том числе НДС 20% 2000 sum.'],
    typeSum: 'В том числе НДС 20% 2000 sum ',
    sum: '4 200 422,00 UZS',
    depositSum: '1 200 500 sum',
    sana: 'Yanvar 2022',
    status: 'Расчётный',
    statusPay: false,
    level: 'Открыт',
    bank: 'Xalq bank',
    rontragent: 0
  },
  {
    id: 2,
    dealNomer: '842104',
    date: '13.12.2022',
    inn: 83120000002560000257,
    contragent: ["ООО 'Future IT  Technolofy'", 'В том числе НДС 90% 2000 sum.'],
    typeSum: 'В том числе НДС 20% 2000 sum ',
    sum: '8 200 422,00 UZS',
    depositSum: '2 100 500 sum',
    sana: 'Fevral 2022',
    status: 'Расчётный',
    statusPay: true,
    level: 'Открыт',
    bank: 'Davr Bank',
    rontragent: 2
  },

  {
    id: 3,
    dealNomer: '242104',
    date: '13.12.2022',
    inn: 23120000004190000143,
    contragent: ["ООО 'Future Open Technolofy'", 'В том числе НДС 20%  2000 рублей.'],
    typeSum: 'В том числе НДС 40% 2000 sum',
    sum: '2 500 000,00 UZS',
    depositSum: '2 200 500 sum',
    sana: 'Yanvar 2022',
    status: 'Расчётный',
    statusPay: true,
    level: 'Открыт',
    bank: 'AsakaBank',
    rontragent: 3
  },

  {
    id: 4,
    dealNomer: '342104',
    date: '13.12.2022',
    inn: 23120000004190000143,
    contragent: ["ООО 'Future Open Technolofy'", 'Оплата услуг'],
    typeSum: 'В том числе НДС 10% 3000 sum',
    sum: '3 145 678,00 USD',
    sana: 'Yanvar 2022',
    depositSum: '3 500 sum',
    status: 'Расчётный',
    statusPay: false,
    level: 'Открыт',
    bank: 'KapitalBank',
    rontragent: 4
  },

  {
    id: 5,
    dealNomer: '542104',
    date: '13.12.2022',
    inn: 23120000002560000257,
    contragent: ["ООО 'Future Open Technolofy'", 'Оплата услуг'],
    typeSum: 'В том числе НДС 25% 2500 sum',
    sum: '2 885 036,00 UZS',
    sana: 'Yanvar 2022',
    depositSum: '1 200 500 sum',
    status: 'Расчётный',
    statusPay: true,
    level: 'Открыт',
    dealNomer: '642104',
    bank: 'Agrobank',
    rontragent: 5
  }
]

export default function secondPage() {
  return (
    <div>
      <TableContainer component={Paper}>
        <Table sx={{ minWidth: 650 }} aria-label='simple table'>
          <TableHead>
            <TableRow>
              <TableCell>№ </TableCell>
              <TableCell>НАЗВАНИЕ ОТЧЁТА (100g serving)</TableCell>
              <TableCell>НАЗВАНИЕ ОТЧЁТА&nbsp;(g)</TableCell>
              <TableCell>СТАТУС&nbsp;(g)</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((item, index) => (
              <TableRow key={index} sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                <TableCell>{item.dealNomer}</TableCell>
                <TableCell>{item.typeSum}</TableCell>
                <TableCell>{item.date}</TableCell>
                <TableCell>{item.status}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  )
}
