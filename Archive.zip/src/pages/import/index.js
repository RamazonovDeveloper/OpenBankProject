// ** MUI Imports
import Card from '@mui/material/Card'
import Grid from '@mui/material/Grid'
import Typography from '@mui/material/Typography'
import CardHeader from '@mui/material/CardHeader'
import CardContent from '@mui/material/CardContent'
import { DataGrid } from '@mui/x-data-grid'
import IconButton from '@mui/material/IconButton'
import Button from '@mui/material/Button'
import Icon from 'src/@core/components/icon'
import Box from '@mui/material/Box';
import Accounts from 'src/views/dashboards/accounts/Accounts'


import TableHeader from 'src/views/apps/invoice/list/TableHeader'

const columns = [
  { field: 'number', headerName: '№', width: 80 },
  { field: 'date', headerName: 'Дата', width: 120 },
  {
    field: 'contragent',
    headerName: 'Контрагент',
    width: 280,
    editable: true,
    renderCell: (params) => {
      return (
        <Box>
          <Typography variant="body1" gutterBottom>
            {params.row.contragent[1]}
          </Typography>
          <Typography variant="body2" gutterBottom>
            {params.row.contragent[0]}
          </Typography>
          <Typography variant="caption" display="block" gutterBottom>
            {params.row.contragent[2]}
          </Typography>
        </Box>
      )
    },
  },
  {
    field: 'sum',
    headerName: 'Сумма',
    width: 150,
    editable: true,
  },
  {
    field: 'status',
    headerName: 'Статус',
    width: 110,
    editable: true,
  },
  {
    field: 'payments',
    headerName: 'Счёт',
    width: 240,
    editable: true,
    renderCell: (params) => {
      return (
        <Box>
          <Typography variant="body2" gutterBottom>
            {params.row.payments[0]}
          </Typography>
          <Typography variant="subtitle2" gutterBottom>
            {params.row.payments[1]}
          </Typography>
        </Box>
      )
    },
  },
  {
    field: 'action',
    headerName: '',
    width: 110,
    editable: true,
    renderCell: (params) => {
      return (
        <div>
          <IconButton onClick={() => console.log(params)} color='inherit' sx={{ ml: -2.75 }} >
            <Icon icon='uil:print' />
          </IconButton>
        </div>
      )
    },
  }
];

const rows = [
  { number: 9119, id: 1, date: '13.12.2022', contragent: ["Платёжное поручение №3091", "Контрагент 2", "В том числе НДС 15% - 1 500 сум."], sum: "-10 000,00 UZS", status: "Подписан", payments: ["23120000002560000257", "ООО 'Future Open Technolofy'", "В том числе НДС 20% 2000 рублей."]},
  { number: 8143, id: 2, date: '13.12.2022', contragent: ["Платёжное поручение №0481", "Контрагент 1", "В том числе НДС 15% - 1 500 сум."], sum: "-10 000,00 UZS", status: "Исполнен", payments: ["23120000004190000143", "ООО 'Future Open Technolofy'", "В том числе НДС 20% 2000 рублей."]},
  { number: 7653, id: 3, date: '13.12.2022', contragent: ["Платёжное поручение №62838", "Контрагент 9", "Оплата услуг"], sum: "-1 700,00 UZS", status: "Исполнен", payments: ["23120000009630000631", "ООО 'Future Open Technolofy'", "В том числе НДС 20% 2000 рублей."]},
  { number: 3452, id: 4, date: '13.12.2022', contragent: ["Платёжное поручение №66189", "Контрагент 8", "Оплата услуг"], sum: "-2 500,00 UZS", status: "Исполнен", payments: ["23120000002560000257", "ООО 'Future Open Technolofy'", "В том числе НДС 20% 2000 рублей."]},
  { number: 2346, id: 5, date: '13.12.2022', contragent: ["Платёжное поручение №46733", "Контрагент 7", "Оплата услуг"], sum: "-1 300,00 UZS", status: "Исполнен", payments: ["23120000002560000257", "ООО 'Future Open Technolofy'", "В том числе НДС 20% 2000 рублей."]},
  { number: 4567, id: 6, date: '13.12.2022', contragent: ["Платёжное поручение №3091", "Контрагент 6", "Оплата услуг"], sum: "-7 424,00 UZS", status: "Исполнен", payments: ["23120000002560000257", "ООО 'Future Open Technolofy'", "В том числе НДС 20% 2000 рублей."]},
  { number: 8765, id: 7, date: '13.12.2022', contragent: ["Платёжное поручение №3091", "Контрагент 3", "Оплата услуг"], sum: "-4 123,00 UZS", status: "Исполнен", payments: ["23120000002560000257", "ООО 'Future Open Technolofy'", "В том числе НДС 20% 2000 рублей."]},
  { number: 3456, id: 8, date: '13.12.2022', contragent: ["Платёжное поручение №3091", "Контрагент 5", "Оплата услуг"], sum: "-3 248,00 UZS", status: "Исполнен", payments: ["23120000002560000257", "ООО 'Future Open Technolofy'", "В том числе НДС 20% 2000 рублей."]},
  { number: 6542, id: 9, date: '13.12.2022', contragent: ["Платёжное поручение №3091", "Контрагент 10", "Оплата услуг"], sum: "-2 804,00 UZS", status: "Исполнен", payments: ["23120000002560000257", "ООО 'Future Open Technolofy'", "В том числе НДС 20% 2000 рублей."]}
];



const Import = () => {
  return (
    <Grid container spacing={4}>
      <Grid item xs={12}>
        <Box sx={{ display: 'flex', width: '100%', alignItems: 'center', justifyContent: "space-between" }}>
          <Box sx={{ display: 'flex', alignItems: 'center'}}>
            <Typography variant='h5' sx={{ mr: 1.75 }}>
                Картотека
            </Typography>
          </Box>      
        </Box>
      </Grid>


      <Grid item xs={12}>
        <Card>
          <TableHeader value={''} selectedRows={""} handleFilter={"handleFilter"} /> 
          <DataGrid
            autoHeight
            pagination
            rows={rows} // komment
            rowHeight={100}
            columns={columns} // komment
            disableSelectionOnClick
            pageSize={Number("10")} // komment
            rowsPerPageOptions={[10, 25, 50]}

            // onSelectionModelChange={rows => setSelectedRows(rows)}
            onPageSizeChange={newPageSize => setPageSize(newPageSize)}
          />
        </Card>
      </Grid>
    </Grid>
  )
}

export default Import
