import React from 'react'

import Grid from '@mui/material/Grid'

//btninptn
import InputLabel from '@mui/material/InputLabel'
import MenuItem from '@mui/material/MenuItem'
import FormControl from '@mui/material/FormControl'
import Select from '@mui/material/Select'
import Button from '@mui/material/Button'

//tablepanel
import PropTypes from 'prop-types'
import Tabs from '@mui/material/Tabs'
import Tab from '@mui/material/Tab'
import Typography from '@mui/material/Typography'
import Box from '@mui/material/Box'
import Card from '@mui/material/Card'
import Icon from 'src/@core/components/icon'

// table
import Table from '@mui/material/Table'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TableHead from '@mui/material/TableHead'
import TableRow from '@mui/material/TableRow'
import Paper from '@mui/material/Paper'

//modal
import Modal from '@mui/material/Modal'
import { fontSize } from '@mui/system'

const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 820,
  bgcolor: '#fff',
  border: 'none',
  boxShadow: 24,
  borderRadius: 2,
  p: 4
}
function createData(name, calories, fat, carbs, protein) {
  return { name, calories, fat, carbs, protein }
}

function TabPanel(props) {
  const { children, value, index, ...other } = props

  return (
    <div
      role='tabpanel'
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  )
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired
}

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`
  }
}

const rows = [
  {
    id: 1,
    dealNomer: '142104',
    date: '13.12.2022',
    inn: 123456789,
    contragent: 'ООО ТЕСТ 1',
    typeSum: 'В том числе НДС 20% 2000 sum ',
    sum: '4 200 422,00 UZS',
    depositSum: '1 200 500 sum',
    sana: 'Yanvar 2022',
    status: 'Расчётный',
    statusPay: false,
    level: 'Открыт',
    bank: "АКБ 'КАПИТАЛБАНК'",
    rontragent: 0,
    mfo: '0069'
  },
  {
    id: 1,
    dealNomer: '842104',
    date: '13.12.2022',
    inn: 987654321,
    contragent: 'ООО ТЕСТ 2',
    typeSum: 'В том числе НДС 20% 2000 sum ',
    sum: '8 200 422,00 UZS',
    depositSum: '2 100 500 sum',
    sana: 'Fevral 2022',
    status: 'Расчётный',
    statusPay: true,
    level: 'Открыт',
    bank: "ЧАКВ 'ОРИЕНТ ФИНАНС'",
    rontragent: 2,
    mfo: '0058'
  },

  {
    id: 2,
    dealNomer: '242104',
    date: '13.12.2022',
    inn: 123456789,
    contragent: 'ООО ТЕСТ 3',
    typeSum: 'В том числе НДС 40% 2000 sum',
    sum: '2 500 000,00 UZS',
    depositSum: '2 200 500 sum',
    sana: 'Yanvar 2022',
    status: 'Расчётный',
    statusPay: true,
    level: 'Открыт',
    bank: "АКБ 'КАПИТАЛБАНК'",
    rontragent: 3,
    mfo: '0069'
  },

  {
    id: 3,
    dealNomer: '342104',
    date: '13.12.2022',
    inn: 987654321,
    contragent: 'ООО ТЕСТ 4',
    typeSum: 'В том числе НДС 10% 3000 sum',
    sum: '145 678,00 USD',
    sana: 'Yanvar 2022',
    depositSum: '3 500 sum',
    status: 'Расчётный',
    statusPay: false,
    level: 'Открыт',
    bank: "ЧАКВ 'КАПИТАЛБАНК'",
    rontragent: 4,
    mfo: '0069'
  },

  {
    id: 4,
    dealNomer: '542104',
    date: '13.12.2022',
    inn: '000000000',
    contragent: 'ООО ТЕСТ 5',
    typeSum: 'В том числе НДС 25% 2500 sum',
    sum: '2 885 036,00 UZS',
    sana: 'Yanvar 2022',
    depositSum: '1 200 500 sum',
    status: 'Расчётный',
    statusPay: true,
    level: 'Открыт',
    dealNomer: '642104',
    bank: "АКБ 'ОРИЕНТ ФИНАНС'",
    rontragent: 5,
    mfo: '0058'
  }
]

export default function Kontragenti() {
  const [age, setAge] = React.useState('')

  const handleChange1 = event => {
    setAge(event.target.value)
  }

  //tabpanel
  const [value, setValue] = React.useState(0)

  const handleChange = (event, newValue) => {
    setValue(newValue)
  }

  //modal
  const [open, setOpen] = React.useState(false)
  const [boshMas, setBoshMas] = React.useState([])

  function handleClose() {
    setOpen(false)
    setBoshMas([])
  }
  function handleOpen(item) {
    boshMas.push(item)
    setOpen(true)
  }

  return (
    <div>
      <Grid sx={{ display: 'flex', width: '100%', alignItems: 'center', justifyContent: 'space-between' }}>
        <Box sx={{ display: 'flex', width: '100%', alignItems: 'center', justifyContent: 'space-between' }}>
          <Typography variant='h5' sx={{ mr: 1.75 }}>
            Контрагенты
          </Typography>
          <Box sx={{ display: 'flex' }}>
            <FormControl sx={{ minWidth: 140, mr: 4 }} size='small'>
              <InputLabel id='demo-select-small'>Импорт и Экспорт</InputLabel>
              <Select
                labelId='demo-select-small'
                id='demo-select-small'
                label='Импорт и Экспорт'
                onChange={handleChange1}
                style={{ width: '200px' }}
              >
                <MenuItem value=''>
                  <em>None</em>
                </MenuItem>
                <MenuItem value={10}>Ten</MenuItem>
                <MenuItem value={20}>Twenty</MenuItem>
                <MenuItem value={30}>Thirty</MenuItem>
              </Select>
            </FormControl>

            <Button variant='contained'>Новый Контрагенты</Button>
          </Box>
        </Box>
      </Grid>
      {/* tab panel */}
      <Card>
        <Box sx={{ width: '100%' }}>
          <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
            <Tabs value={value} onChange={handleChange} aria-label='basic tabs example'>
              <Tab label='Подтверждены' {...a11yProps(0)} />
              <Tab label='Требуют подписания' {...a11yProps(1)} />
            </Tabs>
          </Box>
          <TabPanel value={value} index={0}>
            {/* first tales */}
            <TableContainer component={Paper}>
              <Table sx={{ minWidth: 650 }} aria-label='simple table'>
                <TableHead>
                  <TableRow>
                    <TableCell>
                      <h3>НАИМЕНОВАНИЕ И ИНН</h3>
                    </TableCell>
                    <TableCell align='left'>
                      <h3>НАЗВАНИЕ И БИК БАНКА</h3>
                    </TableCell>
                    <TableCell align='left'>
                      <h3>СТАТУС</h3>
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((item, index) => (
                    <TableRow
                      className='salom'
                      key={item.contragent}
                      onClick={() => handleOpen(item)}
                      sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                    >
                      <TableCell component='th' scope='row'>
                        <Typography>{item.contragent}</Typography>
                        <Typography>ИНН: {item.inn}</Typography>
                      </TableCell>
                      <TableCell align='left'>
                        <Typography>{item.bank}</Typography>
                        <Typography>МФО: {item.mfo}</Typography>
                      </TableCell>
                      <TableCell align='left'>
                        <Icon
                          style={{ color: 'green', fontSize: '25px', fontWeight: 'bold' }}
                          icon='material-symbols:check'
                        />{' '}
                        Подтверждён
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
                <div>
                  <Modal
                    open={open}
                    onClose={handleClose}
                    aria-labelledby='modal-modal-title'
                    aria-describedby='modal-modal-description'
                  >
                    <Box sx={style}>
                      <h2 style={{ paddingLeft: '38px' }}> Open Bank</h2>
                      <hr />
                      <Typography id='modal-modal-description' sx={{ mt: 2 }}>
                        {boshMas.length > 0 ? (
                          boshMas.map((item, index) => {
                            return (
                              <div key={index}>
                                <ul
                                  style={{
                                    display: 'flex',
                                    fontSize: '12px',
                                    gap: '20px',
                                    justifyContent: 'center',
                                    alignItems: 'center'
                                  }}
                                >
                                  <li style={{ fontSize: '14px' }}>
                                    Контрагент{item.rontragent}
                                    <br />
                                    {item.inn}
                                  </li>
                                  <li style={{ fontSize: '14px' }}>
                                    {item.contragent} <br />
                                    {item.dealNomer}
                                  </li>
                                  <li>
                                    <TableCell
                                      style={{
                                        display: 'flex',
                                        justifyContent: 'center',
                                        alignItems: 'center'
                                      }}
                                      align='left'
                                    >
                                      {item.statusPay === true ? (
                                        <Icon
                                          style={{ color: 'green', fontSize: '25px', fontWeight: 'bold' }}
                                          icon='material-symbols:check'
                                        />
                                      ) : (
                                        <Icon
                                          style={{ color: 'red', fontSize: '25px', fontWeight: 'bold' }}
                                          icon='ic:sharp-clear'
                                        />
                                      )}{' '}
                                      Подписан
                                    </TableCell>
                                  </li>
                                </ul>
                                <br />
                                <div style={{ display: 'flex' }}>
                                  <ul>
                                    <li>
                                      <h2>Наименование</h2>
                                    </li>
                                    <li>ИНН / КИО</li>
                                    <li>КПП</li>
                                    <li>БИК банка</li>
                                    <li>Банк</li>
                                    <li>Корр. счёт</li>
                                  </ul>
                                  <ul>
                                    <li>
                                      <h2>Контрагент</h2> {item.rontragent}
                                    </li>
                                    <li>{item.dealNomer}</li>
                                    <li>{item.inn}</li>
                                    <li>{item.depositSum}</li>
                                    <li>{item.bank}</li>
                                    <li>{item.typeSum}</li>
                                  </ul>
                                  <ul>
                                    <li style={{ display: 'flex', alignItems: 'center' }}>
                                      <h4>Контрагент</h4> : {item.rontragent}
                                    </li>
                                    <li style={{ display: 'flex', alignItems: 'center' }}>
                                      <h4>Статус</h4> : {item.statusPay === true ? 'Подписан' : 'Не Подписан'}{' '}
                                    </li>
                                  </ul>
                                </div>
                              </div>
                            )
                          })
                        ) : (
                          <h2>loading.....</h2>
                        )}
                        <hr />
                      </Typography>
                    </Box>
                  </Modal>
                </div>
              </Table>
            </TableContainer>
          </TabPanel>
          <TabPanel value={value} index={1}>
            Нет данных
          </TabPanel>
          <TabPanel value={value} index={2}>
            Нет данных
          </TabPanel>
        </Box>
      </Card>
    </div>
  )
}
