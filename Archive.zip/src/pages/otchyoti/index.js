import { useRouter } from 'next/router'

// ** MUI Imports
import Card from '@mui/material/Card'
import Grid from '@mui/material/Grid'
import Typography from '@mui/material/Typography'
import CardHeader from '@mui/material/CardHeader'
import CardContent from '@mui/material/CardContent'
import { DataGrid } from '@mui/x-data-grid'
import IconButton from '@mui/material/IconButton'
import Button from '@mui/material/Button'
import Icon from 'src/@core/components/icon'
import Box from '@mui/material/Box'
import Accounts from 'src/views/dashboards/accounts/Accounts'

import TableHeader from 'src/views/apps/invoice/list/TableHeader'

const columns = [
  { field: 'date', headerName: 'Дата выписки', width: 220 },
  {
    field: 'contragent',
    headerName: 'Номер счёта',
    width: 280,
    editable: true,
    renderCell: params => {
      return (
        <Box>
          <Typography variant='body1' gutterBottom>
            {params.row.contragent[1]}
          </Typography>
          <Typography variant='body2' gutterBottom>
            {params.row.contragent[0]}
          </Typography>
        </Box>
      )
    }
  },
  {
    field: 'sum',
    headerName: 'На начало дня',
    width: 210,
    editable: true
  },
  {
    field: 'status',
    headerName: 'На конец дня',
    width: 210,
    editable: true
  },
  {
    field: 'payments',
    headerName: 'Списания',
    width: 240,
    editable: true,
    renderCell: params => {
      return (
        <Box>
          <Typography variant='body2' gutterBottom>
            {params.row.payments[0]}
          </Typography>
        </Box>
      )
    }
  },
  {
    field: 'bank',
    headerName: 'Банк',
    width: 210,
    editable: true
  }

  // {
  //   field: 'action',
  //   headerName: '',
  //   width: 110,
  //   editable: true,
  //   renderCell: (params) => {
  //     return (
  //       <div>
  //         <IconButton onClick={() => console.log(params)} color='inherit' sx={{ ml: -2.75 }} >
  //           <Icon icon='uil:print' />
  //         </IconButton>
  //       </div>
  //     )
  //   },
  // }
]

const rows = [
  {
    number: 9119,
    id: 1,
    date: '22.12.2022',
    contragent: ['23120000002560000257', 'Счет'],
    sum: '7 652 452,00 UZS',
    status: '9 585 458,00 UZS',
    payments: ['1 066 994,00 UZS', "ООО 'Future Open Technolofy'", 'В том числе НДС 20% 2000 рублей.'],
    bank: 'Agrobank'
  }
]

const Reports = () => {
  const router = useRouter()

  const handleClick = e => {
    router.push(`/otchyoti/preview/${1}`)
  }

  return (
    <Grid container spacing={4}>
      <Grid item xs={12}>
        <Box sx={{ display: 'flex', width: '100%', alignItems: 'center', justifyContent: 'space-between' }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <Typography variant='h5' sx={{ mr: 1.75 }}>
              Выписки и отчёты
            </Typography>
            <IconButton color='inherit' sx={{ ml: -2.75 }}>
              <Icon icon='ep:setting' />
            </IconButton>
          </Box>
          <Box sx={{ display: 'flex' }}>
            <Button variant='outlined' sx={{ mr: 4 }}>
              Новый отчёт
            </Button>
            <Button variant='contained'>Скачать выписку</Button>
          </Box>
        </Box>
      </Grid>

      <Grid item xs={12}>
        <Card>
          <TableHeader value={''} selectedRows={''} handleFilter={'handleFilter'} />
          <DataGrid
            onRowClick={() => handleClick()}
            autoHeight
            pagination
            rows={rows} // komment
            rowHeight={100}
            columns={columns} // komment
            disableSelectionOnClick
            pageSize={Number('10')} // komment
            rowsPerPageOptions={[10, 25, 50]}
            onPageSizeChange={newPageSize => setPageSize(newPageSize)}
          />
        </Card>
      </Grid>
    </Grid>
  )
}

export default Reports
