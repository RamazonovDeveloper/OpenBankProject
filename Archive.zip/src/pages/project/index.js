import React, { useState } from 'react'
import Box from '@mui/material/Box'
import Tab from '@mui/material/Tab'
import TabContext from '@mui/lab/TabContext'
import TabList from '@mui/lab/TabList'
import TabPanel from '@mui/lab/TabPanel'
import Card from '@mui/material/Card'
import Button from '@mui/material/Button'

import FirstTab from './tabItems/FirstTab'
import ThirdTab from './tabItems/ThirdTab'

// import { FaClock } from 'react-icons/fa';

import IconButton from '@mui/material/IconButton'
import Icon from 'src/@core/components/icon'

//select button
import InputLabel from '@mui/material/InputLabel'
import MenuItem from '@mui/material/MenuItem'
import CardContent from '@mui/material/CardContent'
import FormControl from '@mui/material/FormControl'
import Select from '@mui/material/Select'

//according
import Accordion from '@mui/material/Accordion'
import AccordionDetails from '@mui/material/AccordionDetails'
import AccordionSummary from '@mui/material/AccordionSummary'
import Typography from '@mui/material/Typography'
import { OutlinedInput } from '@mui/material'
import ThridTable from './tabItems/ThirdTab'

export default function Project() {
  const [age, setAge] = useState('')

  const handleChange2 = event => {
    setAge(event.target.value)
  }
  const [value, setValue] = useState('1')

  const handleChange3 = (event, newValue) => {
    setValue(newValue)
  }

  // according function
  const [expanded, setExpanded] = useState(false)

  const handleChange = panel => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false)
  }

  const rows = [
    {
      id: 1,
      dealNomer: '142104',
      date: '13.12.2022',
      nomerschot: 23120000002560000257,
      inn: 555407885,
      contragent: ["ООО 'Future Open Technolofy'"],
      typeSum: 'Заработная плата',
      sum: '4 200 422,00 UZS',
      depositSum: '1 200 500 sum',
      sana: 'Январь 2022',
      status: 'В обработке',
      level: 'Открыт',
      bank: 'МФО - 00018, Мирзо-Улугбеский Agrobank'
    }
  ]

  function searchFun(val) {}

  return (
    <div>
      <Box sx={{ width: '100%', typography: 'body1' }}>
        <Box sx={{ display: 'flex', width: '100%', alignItems: 'center', justifyContent: 'space-between' }}>
          <Box sx={{}}>
            <Typography variant='h5' sx={{ mr: 1.75 }}>
              Зарплатный платы
            </Typography>
          </Box>
          <Box sx={{}}>
            <Button sx={{ height: '40px', border: '1px solid #c1c1c1', color: 'grey' }}>Шаблоны</Button>
            <FormControl sx={{ minWidth: 120, mx: 5 }} size='small'>
              <InputLabel id='demo-select-small'>Экспорт</InputLabel>
              <Select
                labelId='demo-select-small'
                id='demo-select-small'
                value={age}
                label='Экспорт'
                onChange={handleChange2}
              >
                <MenuItem value=''>
                  <em>_</em>
                </MenuItem>
              </Select>
            </FormControl>
            <Button variant='contained' sx={{ mr: 4 }}>
              Создать
            </Button>
          </Box>
        </Box>

        <Card sx={{ mt: 5 }}>
          <TabContext value={value}>
            <TabList
              onChange={handleChange3}
              scrollButtons={false}
              sx={{ borderBottom: theme => `1px solid ${theme.palette.divider}` }}
            >
              <Tab label='Сотрудники' value='1' />
              <Tab label='Выплаты' value='2' />
              <Tab label='Зарплатные карты' value='3' />
            </TabList>

            <TabPanel value='2'>
              <Box sx={{ mb: 3, display: 'flex', width: '100%', alignItems: 'center', textAlign: 'left', ml: 5 }}>
                <Typography sx={{ width: '100px' }} variant='body1'>
                  НОМЕР
                </Typography>
                <Typography sx={{ width: '120px' }} variant='body1'>
                  ДАТА
                </Typography>
                <Typography sx={{ width: '230px' }} variant='body1'>
                  СЧЁТ СПИСАНИЯ
                </Typography>
                <Typography sx={{ width: '250px' }} variant='body1'>
                  ВИД ВЫПЛАТЫ
                </Typography>
                <Typography sx={{ width: '130px' }} variant='body1'>
                  ПЕРИОД
                </Typography>
                <Typography sx={{ width: '150px' }} variant='body1'>
                  СУММА
                </Typography>
                <Typography sx={{ width: '120px' }} variant='body1'>
                  СТАТУС
                </Typography>
              </Box>
              {rows.length > 0 ? (
                rows.map((item, index) => {
                  return (
                    <Accordion key={item} expanded={expanded === item.id} onChange={handleChange(item.id)}>
                      <AccordionSummary
                        className='ekvayring-accoridon'
                        expandIcon={<Icon icon='material-symbols:arrow-drop-down-circle-outline' />}
                      >
                        <Box sx={{ display: 'flex', width: '100%', alignItems: 'center', textAlign: 'left' }}>
                          <Typography sx={{ width: '100px' }}>{item.dealNomer}</Typography>
                          <Typography sx={{ width: '120px' }}>{item.date}</Typography>
                          <Typography sx={{ width: '230px' }}>{item.inn}</Typography>
                          <Typography sx={{ width: '250px' }}>{item.typeSum}</Typography>
                          <Typography sx={{ width: '130px' }}>{item.sana}</Typography>
                          <Typography sx={{ width: '150px' }}>{item.sum}</Typography>
                          <Typography sx={{ width: '120px' }}>{item.status}</Typography>
                        </Box>

                        {/* <Typography sx={{ width: "50px", flexShrink: 0, marginLeft: "20px" }}>{item.dealNomer}</Typography>
                        <Typography sx={{ mr: 10, width: "100px", color: 'text.secondary', marginLeft: "25px" }} >{item.date}</Typography>
                        <Typography sx={{ mr: 10, width: "170px" }} >{item.inn}</Typography>
                        <Typography sx={{ mr: 10, width: "230px", color: 'text.secondary' }} >{item.typeSum}</Typography>
                        <Typography sx={{ mr: 10, width: "100px", color: 'text.secondary' }} >{item.sana}</Typography>
                        <Typography sx={{ mr: 10, width: "150px", color: 'text.secondary' }} >{item.sum}</Typography>
                        <Typography sx={{ mr: 10, width: "80px", color: 'text.secondary' }} >{item.status}</Typography> */}
                      </AccordionSummary>

                      <AccordionDetails style={{ display: 'flex', gap: '200px' }}>
                        <div>
                          <Typography style={{ display: 'flex', alignItems: 'center' }}>
                            {' '}
                            <span style={{ width: '200px' }}>Организация</span>{' '}
                            <p style={{ marginLeft: '100px', textAlign: 'left', width: '350px' }}>
                              {' '}
                              {item.contragent}{' '}
                            </p>
                          </Typography>
                          <Typography style={{ display: 'flex', alignItems: 'center' }}>
                            {' '}
                            <span style={{ width: '200px' }}>ИНН</span>{' '}
                            <p style={{ marginLeft: '100px', textAlign: 'left', width: '350px' }}> {item.inn} </p>{' '}
                          </Typography>
                          <Typography style={{ display: 'flex', alignItems: 'center' }}>
                            {' '}
                            <span style={{ width: '200px' }}>Номер счёта</span>{' '}
                            <p style={{ marginLeft: '100px', textAlign: 'left' }}>{item.nomerschot} </p>{' '}
                          </Typography>
                          <Typography style={{ display: 'flex', alignItems: 'center' }}>
                            {' '}
                            <span style={{ width: '200px' }}>Банк</span>{' '}
                            <p style={{ marginLeft: '100px', textAlign: 'left' }}>{item.bank} </p>{' '}
                          </Typography>
                          <Typography style={{ display: 'flex', alignItems: 'center' }}>
                            {' '}
                            <span style={{ width: '200px' }}>Получатели</span>{' '}
                            <p style={{ marginLeft: '100px', textAlign: 'left', width: '350px' }}> {item.id} </p>{' '}
                          </Typography>
                          <Typography style={{ display: 'flex', alignItems: 'center' }}>
                            {' '}
                            <span style={{ width: '200px' }}>Номер договора</span>{' '}
                            <p style={{ marginLeft: '100px', textAlign: 'left', width: '350px' }}>{item.dealNomer} </p>{' '}
                          </Typography>
                        </div>
                        <div style={{ width: '300px', height: '300px' }}>
                          {/* <img src='https://e7.pngegg.com/pngimages/230/277/png-clipart-alarm-clocks-computer-icons-clock-number-timer.png'/> */}
                          {/* <FaClock style={{ fontSize: "80px" }} /> */}
                          <h4>Зарплатная ведомость находится на исполнении</h4>
                          <p>После положительного ответа банка документ будет переведён в статус «Исполнен».</p>
                        </div>
                      </AccordionDetails>
                    </Accordion>
                  )
                })
              ) : (
                <h2>loading....</h2>
              )}
            </TabPanel>
            <TabPanel value='1'>
              <FirstTab />
            </TabPanel>
            <TabPanel value='3'>
              <ThirdTab />
            </TabPanel>
          </TabContext>
        </Card>
      </Box>
    </div>
  )
}
