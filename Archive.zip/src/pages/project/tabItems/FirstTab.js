import React, { useState } from 'react'
import Styles from '../Project.module.css'
import Box from '@mui/material/Box'
import LogoIcon from '../img/favicon.png'
import Tab from '@mui/material/Tab'
import TabContext from '@mui/lab/TabContext'
import TabList from '@mui/lab/TabList'
import TabPanel from '@mui/lab/TabPanel'
import Button from '@mui/material/Button'
import Image from 'next/image'

// import LogoIcon from "./img/favicon.png"
import IconButton from '@mui/material/IconButton'
import Icon from 'src/@core/components/icon'

//select button
import InputLabel from '@mui/material/InputLabel'
import MenuItem from '@mui/material/MenuItem'
import FormControl from '@mui/material/FormControl'
import Select from '@mui/material/Select'

//according
import Accordion from '@mui/material/Accordion'
import AccordionDetails from '@mui/material/AccordionDetails'
import AccordionSummary from '@mui/material/AccordionSummary'
import Typography from '@mui/material/Typography'
import { OutlinedInput } from '@mui/material'

// tables
import Table from '@mui/material/Table'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TableHead from '@mui/material/TableHead'
import TableRow from '@mui/material/TableRow'
import Paper from '@mui/material/Paper'
import Modal from '@mui/material/Modal'
import { width } from '@mui/system'

const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 600,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4
}

const rows = [
  {
    id: 1,
    dealNomer: '142104',
    date: '13.12.2022',
    inn: 23120000002560000257,
    contragent: ["ООО 'Future Open Technolofy'", 'В том числе НДС 20% 2000 sum.'],
    typeSum: 'В том числе НДС 20% 2000 sum ',
    sum: '4 200 422,00 UZS',
    depositSum: '1 200 500 sum',
    sana: 'Yanvar 2022',
    status: 'Расчётный',
    statusPay: false,
    level: 'Открыт',
    bank: 'Xalq bank',
    rontragent: 0,
    name: 'Ilhomjon Farmonov',
    director: 'Director',
    bankNum: '9860*******3202',
    cardDate: '10/2022'
  },
  {
    id: 1,
    dealNomer: '842104',
    date: '13.12.2022',
    inn: 83120000002560000257,
    contragent: ["ООО 'Future IT  Technolofy'", 'В том числе НДС 90% 2000 sum.'],
    typeSum: 'В том числе НДС 20% 2000 sum ',
    sum: '8 200 422,00 UZS',
    depositSum: '2 100 500 sum',
    sana: 'Fevral 2022',
    status: 'Расчётный',
    statusPay: true,
    level: 'Открыт',
    bank: 'Davr Bank',
    rontragent: 2,
    name: 'Aziz Qoshmatov',
    director: 'Director',
    bankNum: '8600*******1202',
    cardDate: '03/2024'
  },

  {
    id: 2,
    dealNomer: '242104',
    date: '13.12.2022',
    inn: 23120000004190000143,
    contragent: ["ООО 'Future Open Technolofy'", 'В том числе НДС 20%  2000 рублей.'],
    typeSum: 'В том числе НДС 40% 2000 sum',
    sum: '2 500 000,00 UZS',
    depositSum: '2 200 500 sum',
    sana: 'Yanvar 2022',
    status: 'Расчётный',
    statusPay: true,
    level: 'Открыт',
    bank: 'AsakaBank',
    rontragent: 3,
    name: 'Diyor Nzarov',
    director: 'Director',
    bankNum: '9860*******8802',
    cardDate: '07/2023'
  },

  {
    id: 3,
    dealNomer: '342104',
    date: '13.12.2022',
    inn: 23120000004190000143,
    contragent: ["ООО 'Future Open Technolofy'", 'Оплата услуг'],
    typeSum: 'В том числе НДС 10% 3000 sum',
    sum: '145 678,00 USD',
    sana: 'Yanvar 2022',
    depositSum: '3 500 sum',
    status: 'Расчётный',
    statusPay: false,
    level: 'Открыт',
    bank: 'KapitalBank',
    rontragent: 4,
    name: 'Xurshid Rasulov',
    director: 'Director',
    bankNum: '9860*******8802',
    cardDate: '07/2023'
  },

  {
    id: 4,
    dealNomer: '542104',
    date: '13.12.2022',
    inn: 23120000002560000257,
    contragent: ["ООО 'Future Open Technolofy'", 'Оплата услуг'],
    typeSum: 'В том числе НДС 25% 2500 sum',
    sum: '2 885 036,00 UZS',
    sana: 'Yanvar 2021',
    depositSum: '1 200 500 sum',
    status: 'Расчётный',
    statusPay: true,
    level: 'Открыт',
    dealNomer: '642104',
    bank: 'Agrobank',
    rontragent: 5,
    name: 'Nurbek  Jorayev',
    director: 'Director',
    bankNum: '9860*******8802',
    cardDate: '07/2023'
  }
]

export default function FirstTable() {
  // modall
  const [open, setOpen] = useState(false)

  // table funtion
  const [modalMass, setModalMass] = useState([])

  function handleClose() {
    setOpen(false)
    setModalMass([])
  }

  function handleOpen(item) {
    setOpen(true)
    modalMass.push(item)
  }

  return (
    <div>
      <Box className={Styles.mainItems}>
        <TableContainer component={Paper}>
          <Table sx={{ minWidth: 650 }} aria-label='simple table'>
            <TableHead>
              <TableRow>
                <TableCell variant='h2'>ФИО СОТРУДНИКА</TableCell>
                <TableCell variant='h2'>ДОЛЖНОСТЬ</TableCell>
                <TableCell variant='h2'>РЕЗИДЕНТСТВО</TableCell>
                <TableCell variant='h2'>СТАТУС</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {rows.map((item, index) => (
                <TableRow
                  className={Styles.modalStyle}
                  onClick={() => handleOpen(item)}
                  key={index}
                  sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                >
                  <TableCell component='th' scope='row'>
                    {item.name}
                  </TableCell>
                  <TableCell>{item.director}</TableCell>
                  <TableCell>{item.status}</TableCell>
                  <TableCell>{item.level}</TableCell>
                  <TableCell sx={{ width: '20px' }}>
                    <div className={Styles.TableBtn}>...</div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
            <div>
              <Modal
                open={open}
                onClose={handleClose}
                aria-labelledby='modal-modal-title'
                aria-describedby='modal-modal-description'
              >
                <Box sx={style}>
                  <Typography
                    sx={{ display: 'flex', alignItems: 'center', gap: '5px' }}
                    id='modal-modal-title'
                    variant='h6'
                    component='h2'
                  >
                    <Image className={Styles.LogoIcon} src={LogoIcon} alt='' /> Open bank
                  </Typography>
                  <Typography id='modal-modal-description' sx={{ mt: 2 }}>
                    {modalMass.length > 0 &&
                      modalMass.map((item, index) => {
                        return (
                          <Box key={index}>
                            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                              <h3>{item.name}</h3>
                              <Button sx={{ border: '1px solid #6969ed' }}>Изменит</Button>
                            </Box>
                            <Box sx={{ display: 'flex' }}>
                              <ul>
                                <li>Ф.И.О</li>
                                <li>Пол</li>
                              </ul>
                              <ul>
                                <li>{item.name}</li>
                                <li>Мужской</li>
                              </ul>
                            </Box>
                            <hr />
                            <h3>Персональная информация</h3>
                            <Box sx={{ display: 'flex' }}>
                              <ul>
                                <li>Дата рождения</li>
                                <li>Место рождения</li>
                                <li>Тип документа</li>
                                <li>Серия и номер</li>
                                <li>Дата выдачи и окончания</li>
                                <li>Кем выдан</li>
                                <li>ИНН</li>
                              </ul>
                              <ul>
                                <li>{item.date}</li>
                                <li>MmGPUNxlNLPiplejstVHaziaVfjbtg</li>
                                <li>Паспорт гражданина Российской Федерации</li>
                                <li>{item.bankNum}</li>
                                <li>{item.cardDate}</li>
                                <li>FMS</li>
                                <li>{item.inn}</li>
                              </ul>
                            </Box>
                            <hr />
                            <h3>Информация о сотруднике</h3>
                            <Box sx={{ display: 'flex' }}>
                              <ul>
                                <li>Должность</li>
                                <li>Табельный номер</li>
                                <li>Код подразделения</li>
                                <li>Наименование подразделения</li>
                              </ul>
                              <ul>
                                <li>BlxlOhyJdm</li>
                                <li>SJlDUtKbfa</li>
                                <li>fkpFD</li>
                                <li>OIWddwWjGqeIGQWTUVivDQYjbveVHh</li>
                              </ul>
                            </Box>
                          </Box>
                        )
                      })}
                  </Typography>
                </Box>
              </Modal>
            </div>
          </Table>
        </TableContainer>
      </Box>
    </div>
  )
}
