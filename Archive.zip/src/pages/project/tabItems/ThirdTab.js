import React, { useState } from 'react'
import Styles from '../Project.module.css'
import Icon from 'src/@core/components/icon'
import Image from 'next/image'
import LogoIcon from '../img/favicon.png'

// MODAL
import Box from '@mui/material/Box'
import Button from '@mui/material/Button'
import Typography from '@mui/material/Typography'
import Modal from '@mui/material/Modal'

// tables
import Table from '@mui/material/Table'
import TableBody from '@mui/material/TableBody'
import TableCell from '@mui/material/TableCell'
import TableContainer from '@mui/material/TableContainer'
import TableHead from '@mui/material/TableHead'
import TableRow from '@mui/material/TableRow'
import Paper from '@mui/material/Paper'

const rows = [
  {
    id: 1,
    dealNomer: '142104',
    date: '13.12.2022',
    inn: 23120000002560000257,
    contragent: ["ООО 'Future Open Technolofy'", 'В том числе НДС 20% 2000 sum.'],
    typeSum: 'В том числе НДС 20% 2000 sum ',
    sum: '4 200 422,00 UZS',
    depositSum: '1 200 500 sum',
    sana: 'Yanvar 2022',
    status: 'Расчётный',
    statusPay: false,
    level: 'Открыт',
    bank: 'Xalq bank',
    rontragent: 0,
    name: 'Ilhomjon Farmonov',
    director: 'Director',
    img_src:
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRLTBJuabwFMveoks4ffDvmsTPJLBpv0qvGnF_Atl2wDOE-bM2jlg8uFgj1VJ2HXTnyXC0&usqp=CAU',
    bankNum: '9860*******3202',
    cardDate: '10/2022'
  },
  {
    id: 2,
    dealNomer: '842104',
    date: '13.12.2022',
    inn: 83120000002560000257,
    contragent: ["ООО 'Future IT  Technolofy'", 'В том числе НДС 90% 2000 sum.'],
    typeSum: 'В том числе НДС 20% 2000 sum ',
    sum: '8 200 422,00 UZS',
    depositSum: '2 100 500 sum',
    sana: 'Fevral 2022',
    status: 'Расчётный',
    statusPay: true,
    level: 'Открыт',
    bank: 'Davr Bank',
    rontragent: 2,
    name: 'Aziz Qoshmatov',
    director: 'Director',
    img_src:
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTyPBQ9yiIuflPDVLfjx7QkpXsRRXlkP4BxT8Taam7glpLq9EQUFefHPnSLoCiIH-GZkGw&usqp=CAU',
    bankNum: '8600*******1202',
    cardDate: '03/2024'
  },

  {
    id: 3,
    dealNomer: '242104',
    date: '13.12.2022',
    inn: 23120000004190000143,
    contragent: ["ООО 'Future Open Technolofy'", 'В том числе НДС 20%  2000 рублей.'],
    typeSum: 'В том числе НДС 40% 2000 sum',
    sum: '2 500 000,00 UZS',
    depositSum: '2 200 500 sum',
    sana: 'Yanvar 2022',
    status: 'Расчётный',
    statusPay: true,
    level: 'Открыт',
    bank: 'AsakaBank',
    rontragent: 3,
    name: 'Diyor Nzarov',
    director: 'Director',
    img_src:
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQR2p2bSW8eA9sKl6Zg6yKgTCNoPUSCBIz3IWstJLXk7r1VdXD1OukZmoERizJ9XvJl5tA&usqp=CAU',
    bankNum: '9860*******8802',
    cardDate: '07/2023'
  },

  {
    id: 4,
    dealNomer: '342104',
    date: '13.12.2022',
    inn: 23120000004190000143,
    contragent: ["ООО 'Future Open Technolofy'", 'Оплата услуг'],
    typeSum: 'В том числе НДС 10% 3000 sum',
    sum: '145 678,00 USD',
    sana: 'Yanvar 2022',
    depositSum: '3 500 sum',
    status: 'Расчётный',
    statusPay: false,
    level: 'Открыт',
    bank: 'KapitalBank',
    rontragent: 4,
    name: 'Xurshid Rasulov',
    director: 'Director',
    bankNum: '9860*******8802',
    img_src:
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRLTBJuabwFMveoks4ffDvmsTPJLBpv0qvGnF_Atl2wDOE-bM2jlg8uFgj1VJ2HXTnyXC0&usqp=CAU',
    bankNum: '8600*******1202',
    cardDate: '07/2023'
  },

  {
    id: 5,
    dealNomer: '542104',
    date: '13.12.2022',
    inn: 23120000002560000257,
    contragent: ["ООО 'Future Open Technolofy'", 'Оплата услуг'],
    typeSum: 'В том числе НДС 25% 2500 sum',
    sum: '2 885 036,00 UZS',
    sana: 'Yanvar 2022',
    depositSum: '1 200 500 sum',
    status: 'Расчётный',
    statusPay: true,
    level: 'Открыт',
    dealNomer: '642104',
    bank: 'Agrobank',
    rontragent: 5,
    name: 'Nurbek  Jorayev',
    director: 'Director',
    bankNum: '9860*******8802',
    img_src:
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTyPBQ9yiIuflPDVLfjx7QkpXsRRXlkP4BxT8Taam7glpLq9EQUFefHPnSLoCiIH-GZkGw&usqp=CAU',
    bankNum: '9860*******8802',
    cardDate: '07/2023'
  }
]

const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 800,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4,
  borderRadius: '15px'
}

export default function ThridTable() {
  // MODAL FUNCTION
  const [open, setOpen] = useState(false)

  const [modalMass, setModalMass] = useState([])

  function handleClose() {
    setOpen(false)
    setModalMass([])
  }
  function handleOpen(item) {
    modalMass.push(item)
    setOpen(true)
  }

  return (
    <div>
      <Box>
        <TableContainer component={Paper}>
          <Table sx={{ minWidth: 650 }} aria-label='simple table'>
            <TableHead>
              <TableRow>
                <TableCell varient='h3'>№</TableCell>
                <TableCell varient='h3'>ДАТА</TableCell>
                <TableCell varient='h3'>ДОГОВОР</TableCell>
                <TableCell varient='h3'>ВИД ДОКУМЕНТА</TableCell>
                <TableCell varient='h3'>СТАТУС</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {rows.map((item, index) => (
                <TableRow
                  className={Styles.modalStyle}
                  onClick={() => handleOpen(item)}
                  key={index}
                  sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                >
                  <TableCell> {item.id}</TableCell>
                  <TableCell> {item.dealNomer}</TableCell>
                  <TableCell>{item.date}</TableCell>
                  <TableCell>№ {item.inn}</TableCell>
                  <TableCell>{item.bankNum}</TableCell>
                  <TableCell>
                    <Icon style={{ fontSize: '18px', color: '#6969ed' }} icon='material-symbols:check-circle' />{' '}
                    {item.status}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
            {/* <Button onClick={handleOpen}>Open modal</Button> */}
            <Modal
              open={open}
              onClose={handleClose}
              aria-labelledby='modal-modal-title'
              aria-describedby='modal-modal-description'
            >
              <Box sx={style}>
                <Typography
                  sx={{ display: 'flex', alignItems: 'center', gap: '5px' }}
                  id='modal-modal-title'
                  variant='h6'
                  component='h2'
                >
                  <Image className={Styles.LogoIcon} src={LogoIcon} alt='' /> Open bank
                </Typography>{' '}
                <hr />
                <Typography id='modal-modal-description' sx={{ mt: 2 }}>
                  <Box className={Styles.modalHeader}>
                    <Box>
                      <h4>Прикрепление зарплатных карт</h4>
                      <p className={Styles.modalHeadDec}>Документ № 13084311 от 28.12.2022</p>
                    </Box>
                    <Box sx={{ display: 'flex', gap: '5px' }}>
                      <Button className={Styles.modalHeadBtn}>Скопироват</Button> <br />
                      <Button variant='contained' className={Styles.modalHeadBtn2}>
                        Печат(PDF)
                      </Button>
                    </Box>
                  </Box>{' '}
                  <hr />
                  <Box>
                    {modalMass.length > 0 &&
                      modalMass.map((item, index) => {
                        return (
                          <Box
                            key={index}
                            sx={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: '150px'
                            }}
                          >
                            <Box
                              sx={{
                                display: 'flex',
                                alignItems: 'center'
                              }}
                            >
                              <ul className={Styles.modalList}>
                                <li>Статус</li>
                                <li>Подразделение</li>
                                <li>Договор</li>
                                <li>Контактное лицо</li>
                                <li>Контактный телефон</li>
                              </ul>
                              <ul className={Styles.modalList2}>
                                <li>{item.status}</li>
                                <li>{item.bank}</li>
                                <li>
                                  {item.dealNomer} {item.date}
                                </li>
                                <li>{item.name}</li>
                                <li>{item.bankNum}</li>
                              </ul>
                            </Box>
                            <Box className={Styles.modalCards}>
                              <Icon
                                style={{ fontSize: '60px', color: '#6969ed' }}
                                icon='material-symbols:check-circle'
                              />
                              <p>Документ успешно исполнен банком</p>
                              <span>👁‍🗨Приклеплено: 1 карта Детали</span>
                            </Box>
                          </Box>
                        )
                      })}
                    <hr />
                    <Box>
                      <h4>Список сотрудников 1 чел.</h4>
                      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '50px' }}>
                        <input className={Styles.modalnput} placeholder='Введите ФИО Сотруника' type='search' />
                        <Box className={Styles.modaDownBlock}>
                          <p>Скачат печатную форму</p>
                          <Box>
                            <Button>PDF</Button>
                            <Button>Excel</Button>
                          </Box>
                        </Box>
                      </Box>
                      <Box>
                        <TableContainer>
                          <Table>
                            <TableHead>
                              <TableRow>
                                <TableCell>№</TableCell>
                                <TableCell>ФИО СОТРУДНИКА</TableCell>
                              </TableRow>
                            </TableHead>
                            <TableBody>
                              {modalMass.length > 0 &&
                                modalMass.map((item, index) => {
                                  return (
                                    <TableRow key={index} sx={{ background: '#dddcdc' }}>
                                      <TableCell>{item.id}</TableCell>
                                      <TableCell>{item.name}</TableCell>
                                      <TableCell
                                        sx={{
                                          width: '300px',
                                          display: 'flex',
                                          alignItems: 'center',
                                          gap: '15px',
                                          marginLeft: '250px'
                                        }}
                                      >
                                        <img width='80px' src={item.img_src} alt='' /> Карта прикреплена
                                      </TableCell>
                                    </TableRow>
                                  )
                                })}
                            </TableBody>
                          </Table>
                        </TableContainer>
                      </Box>
                    </Box>
                    <hr />
                    <h4>Организацией получено согласие сотрудника на обработку банком персональных данных.</h4>
                  </Box>
                </Typography>
              </Box>
            </Modal>
          </Table>
        </TableContainer>
      </Box>
    </div>
  )
}
