import React from 'react'

const AddNewItemModal = () => {
  return <div>Modal</div>
}

export default AddNewItemModal
